﻿Public Class Clients
    Private Sub ClientsBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles ClientsBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.ClientsBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.DbtestDataSet)

    End Sub

    Private Sub Clients_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DbtestDataSet.Clients' table. You can move, or remove it, as needed.
        Me.ClientsTableAdapter.Fill(Me.DbtestDataSet.Clients)

    End Sub

    Private Sub btnMain_Click(sender As Object, e As EventArgs) Handles btnMain.Click
        Me.Hide()
        Main.Show()
    End Sub

    Private Sub btnSearchLastName_Click(sender As Object, e As EventArgs) Handles btnSearchLastName.Click
        Me.ClientsTableAdapter.FillBy(Me.DbtestDataSet.Clients, txtboxSearchLastName.Text)

    End Sub

    Private Sub btnSeeAll_Click(sender As Object, e As EventArgs) Handles btnSeeAll.Click
        Me.ClientsTableAdapter.Fill(Me.DbtestDataSet.Clients)
    End Sub
End Class