﻿Public Class Main
    Private Sub btnTransForm_Click(sender As Object, e As EventArgs) Handles btnTransForm.Click
        Transactions.Show()
        Me.Hide()

    End Sub

    Private Sub btnTanksForm_Click(sender As Object, e As EventArgs) Handles btnTanksForm.Click
        Tanks.Show()
        Me.Hide()
    End Sub

    Private Sub btnClientsForm_Click(sender As Object, e As EventArgs) Handles btnClientsForm.Click
        Clients.Show()
        Me.Hide()
    End Sub
End Class