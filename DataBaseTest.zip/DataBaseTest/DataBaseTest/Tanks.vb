﻿Public Class Tanks
    Private Sub TanksBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles TanksBindingNavigator.Click
        Me.Validate()
        Me.TanksBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.DbtestDataSet)

    End Sub

    Private Sub Tanks_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DbtestDataSet.Tanks' table. You can move, or remove it, as needed.
        Me.TanksTableAdapter.Fill(Me.DbtestDataSet.Tanks)

    End Sub

    Private Sub btnMain_Click(sender As Object, e As EventArgs) Handles btnMain.Click
        Me.Hide()
        Main.Show()

    End Sub

    Private Sub btn_tanks_In_USE_Click(sender As Object, e As EventArgs) Handles btn_tanks_In_USE.Click
        Me.TanksTableAdapter.FillBy(Me.DbtestDataSet.Tanks)

    End Sub
End Class