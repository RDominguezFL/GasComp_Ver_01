﻿Public Class Transactions
    Private Sub btnMain_Click(sender As Object, e As EventArgs) Handles btnMain.Click
        Main.Show()
        Me.Hide()
    End Sub

    Private Sub Transactions_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DbtestDataSet.Transactions' table. You can move, or remove it, as needed.
        DbtestDataSet.EnforceConstraints = False              'had to turn off the table relationship Key emforcement  i need to fix the relationship requirements 
        Me.TransactionsTableAdapter.Fill(Me.DbtestDataSet.Transactions)


    End Sub

    Private Sub TransactionsBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles TransactionsBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.TransactionsBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.DbtestDataSet)

    End Sub

    Private Sub btnFilter_Click(sender As Object, e As EventArgs) Handles btnFilter.Click
        Me.TransactionsTableAdapter.FillBy(Me.DbtestDataSet.Transactions, txtLastName.Text)


    End Sub


End Class