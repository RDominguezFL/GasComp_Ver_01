﻿

Partial Public Class dbtestDataSet
End Class

Namespace dbtestDataSetTableAdapters

    Partial Public Class TransactionsTableAdapter
    End Class
End Namespace
